# Politica-de-privacidade
Criação de politicas de privacidade 
